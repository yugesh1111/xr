# WeCode - Track 02, EchoGesture: Sign Language Prediction on Edge Device

Python 3.11.

```bash
cd src
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python main.py --videos /path/to/clips --out ../results/predictions.json
```

```python
from main import predict
predict("clip.mp4")
# {"clip_id": "clip", "prediction": "BIRD", "top5": [...], "confidence": 0.87, "latency_ms": 9.8, ...}
```

- `main.py` - `predict(video_path) -> dict`. Runs fully on the device: MediaPipe
  Holistic landmarks -> features -> INT8 ONNX model (`models/model_int8.onnx`,
  6.2 MB). No network access at run time; all models are in `models/`.
- `clip_id` is the file name without its extension. `prediction` is an upper-case
  word from the fixed list in `models/model_meta.json` (WLASL100).
- `latency_ms` is features + classifier for the clip; per-frame landmark time
  is reported next to it (`landmark_ms_per_frame`).
- Conversion script: `scripts/export_onnx.py` (checkpoint -> ONNX FP32 -> INT8).
- Training, evaluation and the Android app are described in the repository:
  https://github.com/yugesh1111/xr
- Headless Linux: `apt-get install libegl1 libgles2 libgl1 libglib2.0-0`
  (MediaPipe needs EGL), or use the `Dockerfile`.
